from src.pet_shop import *
from tests.pet_shop_test import *

if __name__ == '__main__':
    unittest.main()

